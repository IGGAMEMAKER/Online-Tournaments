echo "START SH SCRIPT WORKS!!"
gnome-terminal -x sh -c 'node /home/gaginho/project/NODE/script.js; exec bash'
echo 'SCRIPT script.js WORKS!!'
gnome-terminal -x sh -c 'node /home/gaginho/project/NODE/Admin.js; exec bash'
echo 'SCRIPT Admin.js WORKS!!'
